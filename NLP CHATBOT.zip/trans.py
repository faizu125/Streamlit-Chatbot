import streamlit as st
from googletrans import Translator, LANGUAGES
from docx import Document
import PyPDF2
import io

st.set_page_config(page_title="Translator", page_icon="🌍")
translator = Translator()
translate_button_texts = {
    'af': 'Vertaal',  
    'sq': 'Përktheni',  
    'am': 'ተግባር',  
    'ar': 'ترجم',  
    'hy': 'Թարգմանել',  
    'bn': 'অনুবাদ করুন',  
    'bs': 'Prevedi',  
    'ca': 'Tradueix', 
    'hr': 'Prevedi',  
    'cs': 'Přeložit',  
    'da': 'Oversæt',  
    'nl': 'Vertalen',  
    'en': 'Translate',  
    'eo': 'Traduki',  
    'et': 'Tõlkida',  
    'tl': 'Isalin',  
    'fi': 'Kääntää', 
    'fr': 'Traduire',  
    'de': 'Übersetzen', 
    'el': 'Μεταφράστε',  
    'gu': 'અનુવાદ કરો',  
    'hi': 'अनुवाद करें',  
    'hu': 'Fordítani',  
    'is': 'Þýða',  
    'id': 'Terjemahkan',  
    'it': 'Tradurre',  
    'ja': '翻訳',  
    'jw': 'Tafsirake',  
    'km': 'បកប្រែ',  
    'kn': 'ಅನುವಾದಿಸಿ',  
    'ko': '번역',  
    'la': 'Vertere',  
    'lv': 'Tulkot',  
    'lt': 'Išversti',  
    'mk': 'Преведи',  
    'ml': 'പരിഭാഷിക്കുക',  
    'mr': 'अनुवाद करा',  
    'my': 'ဘာသာပြန်', 
    'ne': 'अनुवाद गर्नुहोस्',  
    'no': 'Oversett', 
    'pl': 'Tłumaczyć', 
    'pt': 'Traduzir',  
    'ro': 'Traduce',  
    'ru': 'Перевести', 
    'sr': 'Преведи',  
    'si': 'පරිවර්තනය කරන්න', 
    'sk': 'Preložiť',  
    'sl': 'Prevedi',  
    'es': 'Traducir', 
    'su': 'Tarjamahkeun',  
    'sw': 'Tafsiri',  
    'sv': 'Översätt',  
    'ta': 'பரிமாற்றம் செய்க', 
    'te': 'భాషాంతరం చేయండి',  
    'th': 'แปล',  
    'tr': 'Çevir', 
    'uk': 'Перекласти',  
    'ur': 'ترجمہ کریں',  
    'vi': 'Dịch',  
    'cy': 'Cyfieithu',  
    'xh': 'Humusha', 
    'yi': 'פֿאַרשטעלן',  
    'zu': 'Humusha',  
    'zh-cn': '翻译',  
    'zh-tw': '翻譯',  
}


def extract_text_from_word(file):
    doc = Document(file)
    text = []
    for para in doc.paragraphs:
        text.append(para.text)
    return "\n".join(text)

def extract_text_from_pdf(file):
    reader = PyPDF2.PdfReader(file)
    text = []
    for page in range(len(reader.pages)):
        text.append(reader.pages[page].extract_text())
    return "\n".join(text)


def main():
    st.title("Multi-Language Text Translator 🌍")
    st.markdown("""Translate text between multiple languages with ease! Select the source and target languages by their names, input the text, and get your translation instantly.""")

    language_names = [name.capitalize() for name in LANGUAGES.values()]
    language_codes = {name.capitalize(): code for code, name in LANGUAGES.items()}
    col1, col2 = st.columns(2)

    with col1:
        source_lang_name = st.selectbox("Select Source Language", options=language_names, index=language_names.index('English'))
        source_lang_code = language_codes[source_lang_name]

    with col2:
        target_lang_name = st.selectbox("Select Target Language", options=language_names, index=language_names.index('Urdu'))
        target_lang_code = language_codes[target_lang_name]

    if source_lang_code == target_lang_code:
        st.error("Source and target languages cannot be the same. Please choose different languages.")
        return

    col1 = st.columns(1)[0]
    
    with col1:
        uploaded_file = st.file_uploader("Upload a Word or PDF file (Optional)", type=["pdf", "docx"])
        text = ""

        if uploaded_file is not None:
            if uploaded_file.type == "application/pdf":
                text = extract_text_from_pdf(uploaded_file)
            elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                text = extract_text_from_word(uploaded_file)

            if not text.strip():
                st.warning("No text found in the uploaded file.")
            else:
                st.text_area("Extracted Text", text, height=300)

        if uploaded_file is None or not text.strip():
            text = st.text_area("Enter Text to Translate", height=300)

    col1 = st.columns(1)[0]

    with col1:
        translate_button_text = translate_button_texts.get(source_lang_code, 'Translate')

        if st.button(translate_button_text):
            if not text.strip():
                st.warning("Please provide text to translate.")
            else:
                try:
                    translated = translator.translate(text, src=source_lang_code, dest=target_lang_code)

                    def get_text_area_height(text: str) -> int:
                        lines = text.split('\n')
                        return min(300, max(100, len(lines) * 20))

                    original_height = get_text_area_height(text)
                    translated_height = get_text_area_height(translated.text)

                    col1, col2 = st.columns(2)

                    with col1:
                        st.subheader(f"Original {source_lang_name}")
                        st.text_area("", text, height=original_height)

                    with col2:
                        st.subheader(f"Translated to {target_lang_name}")
                        st.text_area("", translated.text, height=translated_height)
                except Exception as e:
                    st.error("An error occurred during translation. Please try again.")
                    st.write(f"Error details: {e}")

if __name__ == "__main__":
    main()
