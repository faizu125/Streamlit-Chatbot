import streamlit as st
from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer

st.set_page_config(page_title="Sentiment Analysis", page_icon="🤖")

@st.cache_resource
def load_classifier():
    model_path = "michellejieli/emotion_text_classifier"  
    model = AutoModelForSequenceClassification.from_pretrained(model_path)
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    return pipeline("text-classification", model=model, tokenizer=tokenizer)

classifier = load_classifier()

def preprocess_text(text):
    return text.strip().lower()

st.title("Sentiment Analysis")

user_input = st.text_area("Enter text to analyze emotions:")

if st.button("Analyze"):
    if user_input.strip():
        preprocessed_text = preprocess_text(user_input)
        st.write("**Preprocessed Text:**", preprocessed_text)

        with st.spinner("Analyzing..."):
            result = classifier(preprocessed_text)[0]
            label = result['label']
            score = result['score']

        st.write(f"**Detected Emotion:** {label}")
        st.write(f"**Confidence Score:** {score:.2%}")
        st.progress(int(score * 100))
    else:
        st.warning("Please enter some text for analysis!")
