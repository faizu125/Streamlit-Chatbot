import streamlit as st
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from docx import Document
from docx.shared import RGBColor
import fitz
import io
import os

st.set_page_config(page_title="Plagiarism Detection", page_icon="⚖️")

@st.cache_resource
def load_model():
    local_model_path = "all-MiniLM-L6-v2"  
    model = SentenceTransformer(local_model_path)
    return model

model=load_model()

def extract_text_from_pdf(uploaded_file):
    text = ""
    with fitz.open(stream=uploaded_file.read(), filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_docx(uploaded_file):
    doc = Document(uploaded_file)
    text = ""
    for para in doc.paragraphs:
        text += para.text + "\n"
    return text

def extract_text_from_txt(uploaded_file):
    text = uploaded_file.read().decode("utf-8")
    return text

def calculate_similarity(text1, text2):
    embedding1 = model.encode(text1)
    embedding2 = model.encode(text2)
    similarity = cosine_similarity([embedding1], [embedding2])
    return similarity[0][0]

def compare_files(files):
    file_texts = []
    for file in files:
        file_name = file.name
        if file_name.endswith(".pdf"):
            text = extract_text_from_pdf(file)
        elif file_name.endswith(".docx"):
            text = extract_text_from_docx(file)
        elif file_name.endswith(".txt"):
            text = extract_text_from_txt(file)
        else:
            continue
        file_texts.append((text, file))
    return file_texts

def display_plagiarism_results(file_texts, files):
    plagiarism_detected = False
    first_detection = False
    st.write("### Plagiarism Detection Results")
    for idx1, (text1, file1) in enumerate(file_texts):
        for idx2, (text2, file2) in enumerate(file_texts):
            if idx1 < idx2:
                similarity = calculate_similarity(text1, text2)

                if similarity > 0.8:
                    plagiarism_detected = True
                    st.markdown(f"<p style='color:red; font-size:18px;'>Plagiarism Detected between <b>{file1.name}</b> and <b>{file2.name}</b></p>", unsafe_allow_html=True)
                    st.markdown(f"<p style='color:red; font-size:16px;'>Similarity: <b>{similarity*100:.2f}%</b></p>", unsafe_allow_html=True)

                    if not first_detection:
                        first_detection = True
                        document = Document()
                        document.add_heading('Plagiarism Detected', 0)
                        p = document.add_paragraph()
                        run = p.add_run(f"Plagiarism Detected between {file1.name} and {file2.name}. Similarity: {similarity*100:.2f}%")
                        run.bold = True
                        run.font.color.rgb = RGBColor(255, 0, 0)
                        p.add_run("\n\n")

                        p = document.add_paragraph()
                        p.add_run(f"Content from {file1.name}: \n").bold = True
                        p.add_run(f"{text1}\n").font.color.rgb = RGBColor(0, 0, 0)

                        p = document.add_paragraph()
                        p.add_run(f"Content from {file2.name}: \n").bold = True
                        p.add_run(f"{text2}\n").font.color.rgb = RGBColor(0, 0, 0)
                        byte_io = io.BytesIO()
                        document.save(byte_io)
                        byte_io.seek(0)

                        st.download_button(
                            label="Download Plagiarism Report",
                            data=byte_io,
                            file_name="Detected.docx",
                            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        )

                elif similarity < 0.2:
                    st.markdown(f"<p style='color:green; font-size:18px;'>No Significant Plagiarism Detected between <b>{file1.name}</b> and <b>{file2.name}</b></p>", unsafe_allow_html=True)
                    st.markdown(f"<p style='color:green; font-size:16px;'>Similarity: <b>{similarity*100:.2f}%</b></p>", unsafe_allow_html=True)

                else:
                    st.write(f"Plagiarism Detected between **{file1.name}** and **{file2.name}**")
                    st.write(f"**Similarity:** {similarity*100:.2f}%")

                col1, col2 = st.columns(2)

                with col1:
                    st.subheader(f"Content From {file1.name}")
                    st.text_area("File 1 Content", value=text1, height=400)

                with col2:
                    st.subheader(f"Content From {file2.name}")
                    st.text_area("File 2 Content", value=text2, height=400)
    if plagiarism_detected:
        st.markdown("<p style='color:red; font-size:20px;'>Plagiarism Detected among the Files.</p>", unsafe_allow_html=True)
    else:
        st.markdown("<p style='color:green; font-size:20px;'>No plagiarism Detected among the Files.</p>", unsafe_allow_html=True)
st.title("Plagiarism Detection Tool")
st.write("Upload at least two files (Word, PDF, or TXT). The tool will compare all files to Detect Plagiarism.")

uploaded_files = st.file_uploader("Choose PDF, DOCX, or TXT files", accept_multiple_files=True, type=['pdf', 'docx', 'txt'])

if len(uploaded_files) >= 2:
    file_texts = compare_files(uploaded_files)
    display_plagiarism_results(file_texts, uploaded_files)
else:
    st.warning("Please upload at least two files for plagiarism detection.")
