import os
import streamlit as st
import requests
from dotenv import load_dotenv, set_key
import re
import json

st.set_page_config(page_title="ChatBot", page_icon="💬")

# Load the API key from .env
def load_api_key():
    load_dotenv()
    return os.getenv("gemeni_api_key")

# Update the API key in .env
def update_api_key(new_api_key):
    env_file = ".env"
    set_key(env_file, "gemeni_api_key", new_api_key)
    st.success("API key updated successfully!")

api_key = load_api_key()

if not api_key:
    st.error("Gemini API key not found in .env file. Please set the 'gemeni_api_key' environment variable.")
    st.stop()

# Generate the prompt for conversation history
def generate_prompt(conversation_history):
    conversation = ""
    for message in conversation_history:
        conversation += f"{message['role'].upper()}: {message['content']}\n"
    conversation += "BOT: "  
    return conversation

# Call the Gemini API and get a text response
def get_text_response(conversation_history):
    try:
        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent"
        headers = {"Content-Type": "application/json"}
        prompt = generate_prompt(conversation_history)
        
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ]
        }
        
        params = {"key": api_key}
        response = requests.post(url, headers=headers, params=params, json=payload)
        response.raise_for_status()  # Raise an error for bad HTTP status codes
        data = response.json()
        
        # Debugging logs to check the API response
        print("Response Status Code:", response.status_code)
        print("Response JSON:", json.dumps(data, indent=2))
        
        if "candidates" in data and len(data["candidates"]) > 0:
            # Extract and return the response text from the first candidate
            return data["candidates"][0]["content"]["parts"][0]["text"]
        else:
            return "Sorry, I couldn't understand that. Please try again."
    except requests.exceptions.RequestException as e:
        st.error(f"Request Exception: {e}")
        return "I'm having trouble understanding you right now. Please try again later."
    except KeyError as ke:
        st.error(f"Unexpected response structure: {ke}")
        return "Sorry, I couldn't process your request. Please try again later."

# Streamlit UI
st.title("LLM Bot Using Gemini API")
st.write("Welcome! Ask me anything.")

st.markdown("""
<style>
.chat-container {
    overflow-y: auto;
    color: #0000;
    max-height: 500px;
}
.chat-message {
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 5px;
}
.user-message {
    text-align: right;
    background:  #006400;
    color: white;
}
.bot-message {
    text-align: left;
    background:  #006400;
    color: white;
}
</style>
""", unsafe_allow_html=True)

# Sidebar for API Key management
st.sidebar.header("API Key Management")
new_api_key = st.sidebar.text_input("Enter New API Key", type="password")

if st.sidebar.button("Update API Key"):
    if new_api_key:
        update_api_key(new_api_key)
        api_key = new_api_key  
        st.success("API key updated successfully!")  

if not os.path.exists("chats"):
    os.makedirs("chats")

# Initialize chat session
if "messages" not in st.session_state:
    st.session_state.messages = []

if st.sidebar.button("New Chat"):
    st.session_state.messages = []

# Load chat history
chat_files = [f for f in os.listdir("chats") if f.endswith(".txt")]
shortened_chat_files = [f[:-4] for f in chat_files]  

selected_chat = st.sidebar.radio("History", options=[""] + shortened_chat_files)

if selected_chat and selected_chat != "":
    try:
        full_filename = chat_files[shortened_chat_files.index(selected_chat)]
        with open(os.path.join("chats", full_filename), "r", encoding="utf-8") as f:
            chat_content = f.readlines()

        messages = []
        for line in chat_content:
            if ":" in line:
                role, content = line.split(":", 1)
                role = role.strip().lower()
                content = content.strip()
                if role in ["user", "bot"]:
                    messages.append({"role": role, "content": content})
        st.session_state.messages = messages

    except Exception as e:
        st.error(f"Error loading chat file: {e}")

    if st.sidebar.button(f"❌ Delete {selected_chat}"):
        try:
            os.remove(os.path.join("chats", full_filename))  
        except Exception:
            pass

# Chat message display
st.markdown('<div class="chat-container">', unsafe_allow_html=True)
for message in st.session_state.messages:
    if message["role"] == "user":
        st.markdown(
            f'<div class="chat-message user-message">USER: {message["content"]}</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            f'<div class="chat-message bot-message">BOT: {message["content"]}</div>',
            unsafe_allow_html=True,
        )
st.markdown('</div>', unsafe_allow_html=True)

# Handle user input
def handle_user_input():
    user_input = st.session_state.user_input
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.spinner("Thinking..."):
            bot_response = get_text_response(st.session_state.messages)
        st.session_state.messages.append({"role": "bot", "content": bot_response})
        st.session_state.user_input = ""  # Clear input field

        save_chat_to_file(st.session_state.messages)

# Generate file name from user input
def generate_filename(user_input):
    filename = re.sub(r'[\\/*?:"<>|]', "", user_input)
    return f"{filename[:30]}.txt"

# Save chat to a file
def save_chat_to_file(conversation_history):
    if conversation_history:
        user_question = conversation_history[0]["content"]
        filename = generate_filename(user_question)
        file_path = os.path.join("chats", filename)
        with open(file_path, "w", encoding="utf-8") as f:
            for message in conversation_history:
                f.write(f"{message['role'].upper()}: {message['content']}\n")

# Input field
st.text_input(
    "USER: ",
    key="user_input",
    placeholder="Type your message here...",
    on_change=handle_user_input,
)
