import streamlit as st
import subprocess
import os
from threading import Thread
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
import socket

st.set_page_config(page_title="NLP Application", page_icon="🧠")
FILE_DIR = os.path.dirname(os.path.abspath(__file__))
FILE_NAME = "abt.html"
FILE_PATH = os.path.join(FILE_DIR, FILE_NAME)

class StaticFileServer:
    def __init__(self, host="localhost"):
        self.host = host
        self.server = None
        self.thread = None
        self.port = self.get_free_port()

    def get_free_port(self):
        """Find a free port dynamically."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            return s.getsockname()[1]

    def start(self):
        handler = SimpleHTTPRequestHandler
        self.server = TCPServer((self.host, self.port), handler)
        self.thread = Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        if self.server:
            self.server.shutdown()
            self.thread.join()

server = StaticFileServer()
server.start()

st.markdown("""
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .main-container {
            max-width: 800px;
            margin: 0 auto;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent background */
            padding: 20px;
            border-radius: 15px;
        }
        .title {
            font-size: 2.5rem;
            color: #4CAF50;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .description {
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 30px;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            font-size: 1.1rem;
            font-weight: bold;
            text-align: center;
            color: #fff;
            background-color: #4CAF50;
            border-radius: 8px;
            text-decoration: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }
        .button:hover {
            background-color: #45a049;
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }
        .footer {
            margin-top: 40px;
            font-size: 0.9rem;
            color: #777;
        }
    </style>
""", unsafe_allow_html=True)

st.markdown("""
    <div class="main-container">
        <h1 class="title">NLP Application</h1>
        <p class="description">Click on the corresponding button to run each tool:</p>
    </div>
""", unsafe_allow_html=True)

def run_streamlit_app(script_name):
    subprocess.run(["streamlit", "run", script_name])

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("ChatBot", key="chatbot"):
        run_streamlit_app("chat.py")

    if st.button("Plagiarism Detection Tool", key="plagiarism"):
        run_streamlit_app("palagrism.py")

with col3:
    if st.button("Multi-Language Translator", key="translator"):
        run_streamlit_app("trans.py")

    if st.button("Sentiment Analysis", key="sentiment"):
        run_streamlit_app("classifier.py")

st.markdown(f"""
    <div style="text-align: center; margin-top: 20px;">
        <a class="button" href="http://localhost:{server.port}/{FILE_NAME}" target="_blank">About US</a>
    </div>
""", unsafe_allow_html=True)

